package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// controller for All complains screen
public class AllComplainsController implements Initializable {

    @FXML
    private TableView<Complain> complainsTV;

    @FXML
    private TableColumn<Complain, String> nameCol;

    @FXML
    private TableColumn<Complain, String> complainCol;


    // on back button click listener
    @FXML
    void onBackBtnClick(ActionEvent event) throws IOException {
        Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
        Scene scene = new Scene(parentScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // setting table view data
        nameCol.setCellValueFactory(new PropertyValueFactory<Complain, String>("customerName"));
        complainCol.setCellValueFactory(new PropertyValueFactory<Complain, String>("complain"));

        complainsTV.setItems(EXTRA.getComplains());
    }
}
