package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// controller for log in screen
public class LoginController implements Initializable {

    @FXML
    private TextArea userNameTA;

    @FXML
    private TextArea passwordTA;

    // next button click listener
    @FXML
    void onBackBtnClick(ActionEvent event) {
        if(!EXTRA.validFields(userNameTA,passwordTA)){ // checking if the fields are empty or not
            EXTRA.dialog("Log in failed","Enter username and password.", Alert.AlertType.ERROR);
        } else {
            try {
                if(checkValidity(userNameTA.getText().toString(),passwordTA.getText().toString())){ // checking if the given name and password are correct or not
                    EXTRA.dialog("Logged in","Operation Successful.", Alert.AlertType.INFORMATION);

                    Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
                    Scene scene = new Scene(parentScreen);
                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    window.setScene(scene);
                    window.show();

                } else {
                    EXTRA.dialog("Log in failed","Please check your username or password.", Alert.AlertType.ERROR);
                }
            } catch (IOException | ParseException exception) {
                exception.printStackTrace();
            }
        }
    }


    // method to given if the given name and password are correct or not
    private boolean checkValidity(String userName, String pswd) throws IOException, ParseException {
        // json parser to parse the json file
        JSONParser parser = new JSONParser();
        // obj read from input.json file
        Object obj = parser.parse(new FileReader("input.json"));
        JSONObject jsonObject = (JSONObject)obj;
        // getting name
        String name = (String)jsonObject.get("userName");
        // getting password
        String password = (String)jsonObject.get("password");

        // checking they are equal or not
        if(name.equals(userName) && password.equals(pswd)){
            return  true;
        } else {
            return false;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
