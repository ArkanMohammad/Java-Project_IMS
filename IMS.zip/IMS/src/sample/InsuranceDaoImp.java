package sample;
import java.util.ArrayList;

// Data Access Pattern
// Singleton Design Pattern

// class implementing interface InsuraceDao
public class InsuranceDaoImp implements InsuranceDao {

    private final ArrayList<Insurance> insurances = new ArrayList<>();
    private final ArrayList<Complain> complains = new ArrayList<>();

    private static InsuranceDaoImp instance;

    // private constructor since it is using singleton design pattern
    private InsuranceDaoImp() { }

    // getting instance
    public static InsuranceDaoImp getInstance() {
        // checking if instance is null
        if (instance == null) {
            synchronized (InsuranceDaoImp.class) {
                if (instance == null) {
                    instance = new InsuranceDaoImp();
                }
            }
        }
        return instance;
    }

    // getting insurances arraylist
    @Override
    public ArrayList<Insurance> getAllInsurances() {
        return this.insurances;
    }

    // adding insurance to array list
    @Override
    public void addInsurance(Insurance insurance) {
        insurances.add(insurance);
    }

    // getting complains arraylist
    @Override
    public ArrayList<Complain> getAllComplains() {
        return this.complains;
    }

    // adding complain to array list
    @Override
    public void addComplain(Complain complain) {
        complains.add(complain);
    }

}
