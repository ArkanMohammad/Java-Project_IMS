package sample;

public class Complain {
    // data members
    private String customerName;
    private String complain;

    // constructor
    public Complain(String customerName, String complain) {
        this.customerName = customerName;
        this.complain = complain;
    }

    // getters and setters
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getComplain() {
        return complain;
    }

    public void setComplain(String complain) {
        this.complain = complain;
    }

    // to print the values
    @Override
    public String toString() {
        return "Complain{" +
                "customerName='" + customerName + '\'' +
                ", complain='" + complain + '\'' +
                '}';
    }
}
