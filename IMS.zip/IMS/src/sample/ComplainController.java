package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// controller class for complain screen
public class ComplainController implements Initializable {

    @FXML
    private TextArea nameTA;

    @FXML
    private TextArea complainTA;

    // back button click listner
    @FXML
    void onBackBtnClick(ActionEvent event) throws IOException {
        Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
        Scene scene = new Scene(parentScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    // save button click listner
    @FXML
    void onSaveBtnClick(ActionEvent event) {
        if(EXTRA.validFields(nameTA,complainTA)){ // checking if fields are not empty
            Complain complain = new Complain(nameTA.getText().toString(),complainTA.getText().toString());
            try {
                // adding instance to database
                EXTRA.addComplain(complain);
                // showing dialog
                EXTRA.dialog("Complain Saved","Record Saved Successfully!", Alert.AlertType.INFORMATION);
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        } else {
            // showing dialog
            EXTRA.dialog("Empty Fields","Fields should't empty", Alert.AlertType.ERROR);
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

}
