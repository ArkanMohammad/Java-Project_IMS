package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// controller for health insurance screen
public class HealthInsuranceController implements Initializable {

    @FXML
    private TextArea nameTA;

    @FXML
    private TextArea familyTA;

    @FXML
    private TextArea dateTA;

    @FXML
    private TextArea remarksTA;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }


    // back button click listener
    @FXML
    void onBackBtnClick(ActionEvent event) throws IOException {
        Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
        Scene scene = new Scene(parentScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    // save button click listener
    @FXML
    void onSaveBtnClick(ActionEvent event) {
        if(EXTRA.validFields(nameTA,familyTA,dateTA,remarksTA)){ // checking if fields are not empty
            Insurance insurance = new HealthInsurance(nameTA.getText(),familyTA.getText(),dateTA.getText(),remarksTA.getText());
            try {
                // adding to database and showing dialoge
                EXTRA.addInsurance(insurance);
                EXTRA.dialog("Health Insurance","Record Saved Successfully!", Alert.AlertType.INFORMATION);

            } catch (IOException exception) {
                exception.printStackTrace();
            }
        } else {
            EXTRA.dialog("Empty Fields","Fields should't empty", Alert.AlertType.ERROR);
        }
    }
}
