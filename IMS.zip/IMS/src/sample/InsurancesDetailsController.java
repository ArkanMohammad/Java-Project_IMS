package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

// controller for all insurances
public class InsurancesDetailsController implements Initializable {

    @FXML
    private TableView<Insurance> InsurancesTV;

    @FXML
    private TableColumn<Insurance, String> nameCol;

    @FXML
    private TableColumn<Insurance, String> familyCol;

    @FXML
    private TableColumn<Insurance, String> dateCol;

    @FXML
    private TableColumn<Insurance, String> remarksCol;

    @FXML
    private TableColumn<Insurance, String> insuranceTypeCol;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // setting table view
        nameCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("name"));
        familyCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("familyName"));
        dateCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("date"));
        remarksCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("remarks"));
        insuranceTypeCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("insuranceType"));

        InsurancesTV.setItems(settingTableView());
    }

    // back button click listener
    @FXML
    void onBackBtnClick(ActionEvent event) throws IOException {
        Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
        Scene scene = new Scene(parentScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }


    // setting table view from text file
    private ObservableList<Insurance> settingTableView() {
        ObservableList<Insurance> insurances = FXCollections.observableArrayList();
        Scanner scanner = null;
        Insurance insurance = null;


        try {
            // reading from text file
            scanner = new Scanner(new FileReader("insurances.txt"));
            while (scanner.hasNextLine()) {
                String s = scanner.nextLine();
                String[] details = s.split(",");
                String type = details[4];

                if (InsuranceType.ApartmentInsurance.toString().equals(type)) {

                    insurance = new ApartmentInsurance(details[0], details[1], details[2], details[3]);

                } else if (InsuranceType.CarInsurance.toString().equals(type)) {

                    insurance = new CarInsurance(details[0], details[1], details[2], details[3]);

                } else if (InsuranceType.HealthInsurance.toString().equals(type)) {

                    insurance = new HealthInsurance(details[0], details[1], details[2], details[3]);

                } else if (InsuranceType.LifeInsurance.toString().equals(type)) {

                    insurance = new LifeInsurance(details[0], details[1], details[2], details[3]);

                }

                insurances.add(insurance);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }

        return insurances;
    }

}