package sample;

// Template Design Pattern

// Insurance class also uses in Data access pattern

public abstract class Insurance {

    public abstract String getName();

    public abstract void setName(String name);

    public abstract String getFamilyName();

    public abstract void setFamilyName(String familyName);

    public abstract String getDate();

    public abstract void setDate(String date);

    public abstract String getRemarks();

    public abstract void setRemarks(String remarks);

    public abstract String toString();

    public abstract String getInsuranceType();

}
