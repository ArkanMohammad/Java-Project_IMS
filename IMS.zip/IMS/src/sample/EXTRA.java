package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public interface EXTRA {

    // static method to print dialog
    static void dialog(String headerText, String message, Alert.AlertType alertType){
        Alert alert = new Alert(alertType);
        alert.setTitle("Error");
        alert.setHeaderText(headerText);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // checking fields if they are empty or not
    static boolean validFields(TextArea nameTA,TextArea familyTA,TextArea dateTA,TextArea remarksTA){
        if(nameTA.getText().isEmpty() || familyTA.getText().isEmpty() || dateTA.getText().isEmpty() || remarksTA.getText().isEmpty()){
            return false;
        }else {
            return true;
        }
    }

    // checking fields if they are empty or not
    // overloading method
    static boolean validFields(TextArea textArea1,TextArea textArea2){
        if(textArea1.getText().isEmpty() || textArea2.getText().isEmpty()){
            return false;
        }else {
            return true;
        }
    }

    // adding insurance instance to database
    static void addInsurance(Insurance insurance) throws IOException {
        InsuranceDao dao = InsuranceDaoImp.getInstance();
        dao.addInsurance(insurance);
        settingFile(dao.getAllInsurances());
    }

    // getting all insurances registered in database
    static ObservableList<Insurance> getInsurances(){
        ObservableList<Insurance> observableList = FXCollections.observableArrayList();
        InsuranceDao dao = InsuranceDaoImp.getInstance();
        observableList.addAll(dao.getAllInsurances());

        return observableList;
    }

    // adding complain
    static void addComplain(Complain complain) throws IOException {
        InsuranceDao dao = InsuranceDaoImp.getInstance();
        dao.addComplain(complain);
    }

    // getting all complains
    static ObservableList<Complain> getComplains(){
        ObservableList<Complain> observableList = FXCollections.observableArrayList();
        InsuranceDao dao = InsuranceDaoImp.getInstance();
        observableList.addAll(dao.getAllComplains());

        return observableList;
    }

    // method to write to the file from the arrayList
    private static void settingFile(ArrayList<Insurance> insurances) throws IOException {
        FileWriter locFile = new FileWriter("insurances.txt");

        try {
            for(Insurance i : insurances){
                locFile.write(i.getName() + "," + i.getFamilyName() + "," + i.getDate() + "," + i.getRemarks() + "," + i.getInsuranceType() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (locFile != null) {
                    locFile.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
