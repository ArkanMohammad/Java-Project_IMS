package sample;

import java.util.ArrayList;

// Data Access Pattern

public interface InsuranceDao {
    public ArrayList<Insurance> getAllInsurances();
    public void addInsurance(Insurance insurance);
    public ArrayList<Complain> getAllComplains();
    public void addComplain(Complain complain);

}