package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        Complain complain = new Complain("ali","Laptop is not working");
        EXTRA.addComplain(complain);
        complain = new Complain("anis","Mobile has been broken");
        EXTRA.addComplain(complain);

        settingArrayList();

        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        primaryStage.setTitle("Insurance Company");
        primaryStage.setScene(new Scene(root, 600, 500));
        primaryStage.show();
    }

    private void settingArrayList() {
        Scanner scanner = null;
        Insurance insurance = null;

        try {
            scanner = new Scanner(new FileReader("insurances.txt"));
            while (scanner.hasNextLine()) {
                String s = scanner.nextLine();
                String[] details = s.split(",");
                String type = details[4];


                if (InsuranceType.ApartmentInsurance.toString().equals(type)) {

                    insurance = new ApartmentInsurance(details[0],details[1],details[2],details[3]);

                } else if (InsuranceType.CarInsurance.toString().equals(type)) {

                    insurance = new CarInsurance(details[0],details[1],details[2],details[3]);

                } else if (InsuranceType.HealthInsurance.toString().equals(type)) {

                    insurance = new HealthInsurance(details[0],details[1],details[2],details[3]);

                } else if (InsuranceType.LifeInsurance.toString().equals(type)) {

                    insurance = new LifeInsurance(details[0],details[1],details[2],details[3]);

                }

                InsuranceDao dao = InsuranceDaoImp.getInstance();
                dao.addInsurance(insurance);

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
