package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// controller for purchases controller
public class PurchasesController implements Initializable {

    @FXML
    private TableView<Insurance> purchasesTV;

    @FXML
    private TableColumn<Insurance, String> nameCol;

    @FXML
    private TableColumn<Insurance, String> familyCol;

    @FXML
    private TableColumn<Insurance, String> dateCol;

    @FXML
    private TableColumn<Insurance, String> remarksCol;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // setting cell value factory of table view
        nameCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("name"));
        familyCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("familyName"));
        dateCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("date"));
        remarksCol.setCellValueFactory(new PropertyValueFactory<Insurance, String>("remarks"));

        // setting data to table view
        purchasesTV.setItems(EXTRA.getInsurances());
    }

    // back button click listener
    @FXML
    void onBackBtnClick(ActionEvent event) throws IOException {
        Parent parentScreen = FXMLLoader.load(getClass().getResource("main.fxml"));
        Scene scene = new Scene(parentScreen);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

}
