package sample;

// Template Design Pattern

// class inherited from insurance class
public class CarInsurance extends Insurance {

    // data members
    private String name;
    private String familyName;
    private String date;
    private String remarks;
    private InsuranceType insuranceType;

    // constructor
    public CarInsurance(String name, String familyName, String date, String remarks) {
        this.name = name;
        this.familyName = familyName;
        this.date = date;
        this.remarks = remarks;
        this.insuranceType = InsuranceType.CarInsurance;
    }

    // overriden methods from Insurance class

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getFamilyName() {
        return familyName;
    }

    @Override
    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String getRemarks() {
        return remarks;
    }

    @Override
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public String getInsuranceType() {
        return insuranceType.toString();
    }

    @Override
    public String toString() {
        return "CarInsurance{" +
                "name='" + name + '\'' +
                ", familyName='" + familyName + '\'' +
                ", date='" + date + '\'' +
                ", remarks='" + remarks + '\'' +
                ", insuranceType='" + insuranceType + '\'' +
                '}';
    }
}
