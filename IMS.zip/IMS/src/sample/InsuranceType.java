package sample;

public enum InsuranceType {
    CarInsurance,
    ApartmentInsurance,
    LifeInsurance,
    HealthInsurance,
}
